# Supplementary code — anonymized

This archive contains the code needed to reproduce the paper's claims. It is
**anonymized** for double-blind review; repository URLs and author identifiers
have been removed.

## What is here

```
dla/                          core learner
  transformer_dla.py          the DLA mechanism mounted on a GPT backbone
                              (W_eff = W_slow + softplus(P) * W_fast, wake/sleep,
                              consolidation pathways, energy-matched shuffle)
  config.py, model.py, metrics.py

analysis/wfast_geom/          experiment + audit scripts
  audit_b3.py                 consolidation ablations: direct|nocons|shufwrite|
                              uniformwrite|topwrite|qonly|nosleep|full
  audit_t10.py                10-task cross-domain continual-learning run
  audit_second.py             second-backbone (Shakespeare char GPT) replication
  audit_scale.py              large-backbone (GPT-2 family) scale probe
  p1.py, p1b_grad0_null.py,   W_fast geometry: gradient trajectory, directional
  p1c_robustness.py,          alignment, null controls, permutation tests
  p1d_within_task.py,
  p2.py, p4_consolidation_geom.py
  a1_final.py,                write-strength (gamma) sweep tabulation
  a1_dose_response_fig.py
  unified_summary.py          aggregation of the unified n=12 batch
  mechanism_chain_fig.py      figure generation
  bench_scale.py              step-time / peak-VRAM measurement for sizing runs

docs/
  mechanism_chain.md          the formalised mechanism chain (equations, evidence
                              level per arrow, falsifiers)
  scale_experiment.md         deployment guide for the large-backbone probe
```

## How the claims map to scripts

| Claim in the paper | Script | Contrast |
|---|---|---|
| Carrier is causal ($W_{\mathrm{fast}}$ swap) | `audit_second.py`, `p1*.py` | HE$+$EH vs EH$+$HE $W_{\mathrm{fast}}$ injection |
| Only the direct write works | `audit_b3.py` | `direct` vs `nocons` vs `qonly` |
| **Allocation is necessary (core)** | `audit_b3.py` | `direct` vs `shufwrite` (energy-matched permutation) |
| Write-strength robustness | `audit_b3.py --gamma`, `a1_final.py` | paired gap at $\gamma\in\{0.5,1,1.5\}$ |
| Retention / sleep boundary | `audit_b3.py` | `direct` vs `nocons` vs `nosleep` |
| Directional (correlational) alignment | `p1.py`, `p1b_grad0_null.py`, `p1c_robustness.py` | $\cos(g_0,\Delta_{\mathrm{hist}})$ vs gain@40, permutation + FDR |
| 10-task continual learning | `audit_t10.py` | per-task relative forgetting |

## Reproducing a contrast

The consolidation contrasts are CPU-runnable and small:

```bash
python analysis/wfast_geom/audit_b3.py \
  --seed 0 --variant direct --out results/direct_s0
python analysis/wfast_geom/audit_b3.py \
  --seed 0 --variant shufwrite --out results/shuf_s0
```

Each records `birth_ppl`, `ret_ppl`, `Q_norm`, `Wfast_norm`, `Wslow_norm`,
`cons_write_Q_total`, `cons_write_direct_total`, `post_ppl`, `gain40`, `LE_D`,
`T80_D` as JSON.

Aggregate over seeds with `unified_summary.py`; it reports per-seed values and
paired statistics rather than pooled means only.

## Requirements

`torch`, `numpy`, `matplotlib`. The large-backbone probe additionally needs
`transformers` and `tiktoken`. A pretrained nanoGPT-style checkpoint is required
as the backbone; the paper uses a 6.59M Chinese character GPT (6 layers, 8 heads,
256 dim, vocab 7280) and a 10.65M Shakespeare char GPT.

## Notes on determinism

Reported runs used a parity-validated harness (Apple M2 CPU; mean
$|\Delta\mathrm{ppl}|\approx0.24$ against archived server runs). Evaluation RNG
seeds are fixed per contrast; the residual non-determinism is quantified in the
paper's reproducibility statement and is $\approx$2\% of one standard deviation,
far below every reported effect.

## Anonymity

No author names, affiliations, or repository URLs appear in this archive.
